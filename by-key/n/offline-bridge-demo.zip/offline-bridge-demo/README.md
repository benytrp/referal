# Offline Artifact Bridge Demo

A tiny, no-deps sample showing **offline-first, inter-document communication** between HTML artifacts.
It uses:
- `BroadcastChannel` with `localStorage` fallback for **cross-tab messaging**
- **IndexedDB** for shared, durable state
- (Optional) **Service Worker** for caching assets offline (requires https/localhost)

## Files
- `index.html` — Hub that opens both modules and shows bridge messages
- `intake.html` — Create tickets (writes to IndexedDB and broadcasts messages)
- `board.html` — View tickets (reads from IndexedDB, listens to broadcasts, sends acks)
- `bridge.js` — Cross-document messaging helper
- `db.js` — Minimal IndexedDB wrapper
- `sw.js` — Offline cache
- `styles.css` — Minimal styling

## How to run
1. Unzip and serve the folder via a local server (needed for Service Worker):
   - Python: `python3 -m http.server 8080` (then visit http://localhost:8080/)
   - Node: `npx http-server -p 8080`
   - Or any static server on localhost/https
2. Open `index.html` and click **Open Intake** and **Open Board**.
3. Create a ticket in **Intake** and watch it appear in **Board** in real time.
4. Close your network connection — everything still works (cached + local DB).

## Notes
- If the SW can't register (e.g., opened as `file://`), the demo still works; it just won't precache assets.
- This is intentionally minimal so you can extend it for your research scenarios (CRM-style modules, editors, etc.).

Generated: 2025-08-10T22:04:56.405142Z
