// Minimal IndexedDB helper for shared state
const DB_NAME = 'ArtifactEcosystem';
const DB_VERSION = 1;

function withDB(store, mode, fn) {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains('tickets')) db.createObjectStore('tickets', { keyPath: 'id' });
      if (!db.objectStoreNames.contains('logs')) db.createObjectStore('logs', { autoIncrement: true });
    };
    req.onsuccess = () => {
      const db = req.result;
      const tx = db.transaction(store, mode);
      const st = tx.objectStore(store);
      Promise.resolve(fn(st)).then(result => {
        tx.oncomplete = () => resolve(result);
        tx.onerror = () => reject(tx.error);
      }).catch(reject);
    };
    req.onerror = () => reject(req.error);
  });
}

const DB = {
  addTicket(t) { return withDB('tickets', 'readwrite', st => st.put(t)); },
  listTickets() {
    return withDB('tickets', 'readonly', st => new Promise(res => {
      const out = [];
      st.openCursor().onsuccess = e => {
        const c = e.target.result;
        if (c) { out.push(c.value); c.continue(); } else res(out);
      };
    }));
  },
  log(evt) { return withDB('logs', 'readwrite', st => st.add(evt)); }
};
