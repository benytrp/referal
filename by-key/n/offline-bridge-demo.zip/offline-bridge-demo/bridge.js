// Bridge: cross-document messaging with BroadcastChannel + localStorage fallback
class Bridge {
  constructor({ channelName = 'artifact-bridge' } = {}) {
    this.channelName = channelName;
    this.handlers = [];
    this.id = Math.random().toString(36).slice(2);
    this.bc = (typeof BroadcastChannel !== 'undefined') ? new BroadcastChannel(channelName) : null;
    if (this.bc) {
      this.bc.onmessage = (ev) => this._recv(ev.data);
    }
    window.addEventListener('storage', (e) => {
      if (e.key !== '__bridge__') return;
      try {
        const msg = JSON.parse(e.newValue);
        if (msg && msg.sender !== this.id) this._recv(msg);
      } catch {}
    });
  }
  on(fn) { this.handlers.push(fn); }
  send(type, payload) {
    const msg = { type, payload, ts: Date.now(), sender: this.id };
    if (this.bc) this.bc.postMessage(msg);
    else localStorage.setItem('__bridge__', JSON.stringify(msg));
    return msg;
  }
  _recv(msg) { this.handlers.forEach(fn => fn(msg)); }
}
